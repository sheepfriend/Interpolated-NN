import numpy as np
import matplotlib.pyplot as plot

a=np.ones([3,8,8,2])
c=np.zeros([3,8,8,2])
e=np.ones([3,8,8,2])
d=np.zeros([3,8,8,2])
true=np.ones([3,8,8,2])


def fun(gamma,d):
	tmp1 = (1+gamma**2/d/(d-2*gamma))
	tmp2 = (d-gamma)/(d+2-gamma)*(d+2)/d
	return (tmp1**(4/(d+4)))*(tmp2**(2*d/(d+4)))

model='model3/with_cv/'
num=500
index=5


for j in range(0,3):
	for k in range(index,index+1):
		for i in range(0,7):
			try:
				true[j,i+1,k,0] = fun([2,5,10][j]*[0.05,0.1,0.15,0.2,0.25,0.3,0.35][i],[2,5,10][j])
				b=np.load(model+'inter_'+str([2,5,10][j]*[0.05,0.1,0.15,0.2,0.25,0.3,0.35][i])+'_'+str(k)+'_'+str([2,5,10][j])+'.npy')
				aa=b[:num,2]/b[:num,6]
				tmp=np.nanmean(aa[aa!=np.inf])
				tmp1=np.nanstd(aa[aa!=np.inf])
				a[j,i+1,k,0] = tmp
				c[j,i+1,k,0] = tmp1#/np.sqrt(500)
				b=np.load(model+'cis_'+str([2,5,10][j]*[0.05,0.1,0.15,0.2,0.25,0.3,0.35][i])+'_'+str(k)+'_'+str([2,5,10][j])+'.npy')
				print(k)
				b1=np.load(model+'cis_0_'+str(k)+'_'+str([2,5,10][j])+'.npy')
#				print([k,2])
#				print(b1[:num,0])
				aa=b[:num,0]/b1[:num,0]
				aa[aa==np.inf]=1
				aa[aa==np.nan]=1
#				print(aa)
				tmp=np.nanmean(aa[aa!=np.inf])
				tmp1=np.nanstd(aa[aa!=np.inf])
				#print(b[:num,0]/b1[:num,0])
				print([k,tmp,tmp1])
				e[j,i+1,k,0] = tmp
				d[j,i+1,k,0] = tmp1#/np.sqrt(500)
			except:
				pass


color = ['#1aa0dd','#851add','#dd1a78','#dd541a','#ffd230','#07b71e']

x=np.array([0,0.05,0.1,0.15,0.2,0.25,0.3,0.35])

k=5

fig,plots = plot.subplots(2,2,gridspec_kw={ 'wspace':0.25,'hspace':0.35 })

fig.set_figheight(5)
fig.set_figwidth(10)

for j in [0,1]:
	print(j)
	print(a[j,:,index,0])
	print(true[j,:,index,0])
	print(e[j,:,index,0])
	print(np.sqrt(true[j,:,index,0]))
	plots[j,0].plot(x,a[j,:,index,0],color=color[j],marker="+",linestyle='-',label='sampled' )
	plots[j,0].plot(x,true[j,:,index,0],color=color[j],marker="+",linestyle='--',label='true' )
	plots[j,0].fill_between(x, a[j,:,index,0]-c[j,:,index,0] ,a[j,:,index,0]+c[j,:,index,0],  color=color[j],alpha=0.4)
	plots[j,1].plot(x,e[j,:,index,0],color=color[j],marker="+",linestyle='-',label='sampled')
	plots[j,1].plot(x,np.sqrt(true[j,:,index,0]),color=color[j],marker="+",linestyle='--',label='true')
	plots[j,1].fill_between(x, e[j,:,index,0]-d[j,:,index,0] ,e[j,:,index,0]+d[j,:,index,0],  color=color[j],alpha=0.4)
	plots[j,0].set_ylabel('Regret Ratio')
	plots[j,1].set_ylabel('CIS Ratio')
	plots[j,0].legend()
	plots[j,1].legend()
	plots[j,0].set_title('d='+str([2,5,10][j]))
	plots[j,1].set_title('d='+str([2,5,10][j]))


plots[j,0].set_xlabel('omega')
plots[j,1].set_xlabel('omega')

plot.savefig(model+'result.pdf')
plot.show()
