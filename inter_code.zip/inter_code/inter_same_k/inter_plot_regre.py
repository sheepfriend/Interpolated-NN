import numpy as np
import matplotlib.pyplot as plot

a=np.ones([3,8,8,2])
c=np.zeros([3,8,8,2])
e=np.ones([3,8,8,2])
d=np.zeros([3,8,8,2])
true=np.ones([3,8,8,2])


def fun(gamma,d):
	tmp1 = (d-gamma)**2/d/(d-2*gamma)
	tmp2 = (d-gamma)**2/(d+2-gamma)**2*(d+2)**2/d**2
	return 1/(1+d/4)*(tmp1+tmp2*d/4)

model='regre/'
num=400
index=5


for j in range(0,3):
	for k in range(0,8):
		for i in range(0,7):
			try:
				true[j,i+1,k,0] = fun([2,5,10][j]*[0.05,0.1,0.15,0.2,0.25,0.3,0.35][i],[2,5,10][j])
				b=np.load(model+'inter_'+str([2,5,10][j]*[0.05,0.1,0.15,0.2,0.25,0.3,0.35][i])+'_'+str(k)+'_'+str([2,5,10][j])+'.npy')
				aa=b[:num,2]/b[:num,6]
				print(aa)
				tmp=np.nanmean(aa[aa!=np.inf])
				tmp1=np.nanstd(aa[aa!=np.inf])
				a[j,i+1,k,0] = tmp
				c[j,i+1,k,0] = tmp1#/np.sqrt(500)
			except:
				pass


color = ['#1aa0dd','#851add','#dd1a78','#dd541a','#ffd230','#07b71e']

x=np.array([0,0.05,0.1,0.15,0.2,0.25,0.3,0.35])

k=5

fig,plots = plot.subplots(1,2,gridspec_kw={ 'wspace':0.25,'hspace':1.3, 'bottom':0.3 })

fig.set_figheight(3)
fig.set_figwidth(10)

for j in [0,1]:
	print(j)
	print(a[j,:,index,0])
	print(true[j,:,index,0])
	print(e[j,:,index,0])
	print(np.sqrt(true[j,:,index,0]))
	plots[j].plot(x,a[j,:,index,0],color=color[j],marker="+",linestyle='-',label='sampled' )
	plots[j].plot(x,true[j,:,index,0],color=color[j],marker="+",linestyle='--',label='true' )
	plots[j].fill_between(x, a[j,:,index,0]-c[j,:,index,0] ,a[j,:,index,0]+c[j,:,index,0],  color=color[j],alpha=0.4)
	plots[j].set_ylabel('MSE Ratio')
	plots[j].legend()
	plots[j].set_title('d='+str([2,5,10][j]))


plots[0].set_xlabel('omega')
plots[1].set_xlabel('omega')

plot.savefig(model+'result.pdf')
plot.show()
