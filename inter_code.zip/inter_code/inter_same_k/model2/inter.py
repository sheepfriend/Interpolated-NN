import numpy as np
import sys
from scipy.stats import norm
from scipy.stats import laplace


gamma = [0.05,0.1,0.15,0.2,0.25,0.3,0.35,0.4]
gamma = gamma[int(sys.argv[1])]
# n_range = [8,9,10,11,12,13,14,15,16,17]
n_range = int(sys.argv[2])
dim = int(sys.argv[3])
gamma = dim*gamma
n_test = 5000
time = 500
num_fold = 5
print([gamma,n_range])

def train(train_x,train_y,test_x,test_y,k_max, gamma,test_true_y,test_mean_y):
	dim = test_x.shape[1]
	n_train = train_y.size
	n_test = test_y.size
	predict = np.zeros([n_test, k_max])
#	print("gamma: "+str(gamma))
	for i in range(0,n_test):
		dist = train_x - test_x[i,:].repeat(n_train).reshape([dim, n_train]).transpose()
		dist = dist*dist
		dist = np.apply_along_axis(np.sum, 1, dist).reshape(n_train)
		dist = np.sqrt(dist)
		order = dist.argsort()
		tmp_train_y = train_y[order]
		tmp_dist = dist[order]
		if tmp_dist[0] > 0:
			tmp_dist = np.power(tmp_dist, -gamma)
			result = tmp_train_y*tmp_dist
			result = result.cumsum()
			result = result / tmp_dist.cumsum()
			result = result.reshape(n_train)
			result = result[range(0,k_max)]
		else:
			result = tmp_train_y[0].repeat(k_max).reshape(k_max)
		predict[i,:] = result.copy()
	predict[predict>0.5] = 1
	predict[predict<=0.5] = 0
	predict = predict - test_true_y.repeat(k_max).reshape([n_test,k_max])
	predict = predict*predict*np.abs(1-2*test_mean_y).repeat(k_max).reshape([n_test,k_max])
	predict = np.apply_along_axis(np.sum, 0, predict).reshape(k_max)
	return predict/n_test


def cv(train_x,train_y,test_x,test_y,num_fold,k_max,gamma,test_true_y,test_mean_y,default_k=-1):
	k_max = int(k_max)
	dim = train_x.shape[1]
	n_train = train_y.size
	num_each = int(n_train / num_fold)
	predict = np.zeros([num_fold, k_max])
	for i in range(0,num_fold):
		start = num_each*i
		end = num_each*(i+1) - 1
		end = min(end,n_train)
		train_index = range(start,end+1)
		index = range(0,n_train)
		test_index = np.concatenate((index[:start],index[(end+1):]))
		test_index = test_index.astype('int')
		x2 = train_x[train_index,:]
		x1 = train_x[test_index,:]
		y2 = train_y[train_index]
		y1 = train_y[test_index]
	predict = np.apply_along_axis(np.mean, 0, predict).reshape(k_max)
	opt_k = predict.argsort()[0]
	opt_k = int(round(opt_k*(num_fold/(num_fold-1))**(4/(4+dim))))+1
	result = train(train_x=train_x,train_y=train_y,test_x=test_x,test_y=test_y,gamma=gamma,k_max=k_max,test_true_y=test_true_y,test_mean_y=test_mean_y)#[opt_k-1]
	if default_k == -1:
		opt_k = result.argsort()[0]+1
		result_min = np.min(result)
	else:
		opt_k = default_k
		result_min = result[opt_k]
	return [n_train, opt_k, result_min,result]



def eta(x):
	n = x.shape[0]
	x1 = np.power(x,2)
	haha =  np.matmul(x,np.array(range(0,int(dim))).transpose()-dim/2+0.5)/np.sqrt(dim)  
	haha=np.exp(haha)
	haha1 = np.exp( 2*np.matmul(x,np.array(range(0,int(dim))).transpose()-dim/2+0.5)/np.sqrt(dim)  )
#	haha = haha.reshape(int(n))
	# print(haha/(haha+1/haha1))
	return haha/(haha+1/haha1)


def eta(x):
	n = x.shape[0]
	p1 = norm.pdf(x,loc=0,scale=1)/2+norm.pdf(x,loc=3,scale=2)/2
	p2 = norm.pdf(x,loc=1.5,scale=1)/2+norm.pdf(x,loc=4.5,scale=2)/2
	#p2 = laplace.pdf(x)
	p1 = np.apply_along_axis(np.prod, 1, p1)
	p2 = np.apply_along_axis(np.prod, 1, p2)
	return p1/(p1+p2)

def generate(n,dim):
	#x1 = laplace.rvs(size=int(n*dim/2) ).reshape(int(n/2),dim)
	x1 = norm.rvs(loc=0,scale=1,size=int(n*dim/4)).reshape(int(n/4),dim)
	x2 = norm.rvs(loc=3,scale=2,size=int(n*dim/4)).reshape(int(n/4),dim)
	x3 = norm.rvs(loc=1.5,scale=1,size=int(n*dim/4)).reshape(int(n/4),dim)
	x4 = norm.rvs(loc=4.5,scale=2,size=int(n*dim/4)).reshape(int(n/4),dim)
	x = np.concatenate((x1,x2,x3,x4),axis = 0)
	x = x[np.random.permutation(n),:]
	return x

result=[]
dim = int(dim)
for i in range(n_range,n_range+1):
	result=[]
	all_result=[]
	all_result_0 = []
	n_train = np.power(2,i)*64
	#print([i,n_train,np.power(2,i),n_range])
	np.random.seed(1)
	k_max = n_train -100
	tmp_result = np.zeros([time,8])
	for j in range(0,time):
		train_x = generate(n_train,dim)
		train_y_eta = eta(train_x).reshape(n_train)
#		print(train_y_eta)
		train_y_tmp = np.random.uniform(0,1,n_train)
		train_y = train_y_eta.copy()
		train_y[ train_y_eta > train_y_tmp ] = 1
		train_y[ train_y_eta < train_y_tmp ] = 0
		test_x = generate(n_test,dim)
		test_y_eta = eta(test_x).reshape(n_test)
		test_y_tmp = np.random.uniform(0,1,n_test)
		test_y = test_y_eta.copy()
		test_y_true = test_y_eta.copy()
		test_y_true[ test_y_eta > 0.5] = 1
		test_y_true[test_y_eta<0.5] = 0
		test_y[ test_y_eta > test_y_tmp ] = 1
		test_y[ test_y_eta < test_y_tmp ] = 0
		tmp1 = test_y_true - test_y#1-np.sum(test_y[test_y_eta>0.5])/n_test-np.sum(test_y1[test_y_eta<0.5])/n_test		
		tmp1 = tmp1*tmp1
		tmp = cv(train_x=train_x,train_y=train_y,test_x=test_x,test_y=test_y,k_max=k_max,num_fold = num_fold, gamma=0.,test_true_y=test_y_true,test_mean_y=test_y_eta)
		all_result_0.append(tmp[3])
		tmp[3] = np.mean(tmp1)
		tmp_result[j,4:8] = tmp
		tmp = cv(train_x=train_x,train_y=train_y,test_x=test_x,test_y=test_y,k_max=k_max,num_fold = num_fold, gamma=gamma,test_true_y=test_y_true,test_mean_y=test_y_eta)
		all_result.append(tmp[3])
		tmp[3]=np.mean(tmp1)
		tmp_result[j,0:4] = tmp
		print([i,j,np.round(tmp_result[j,],4)])
		np.save("inter_"+str(gamma)+"_"+str(i)+"_"+sys.argv[3]+".npy",tmp_result)
	result.append(np.apply_along_axis(np.mean, 0, tmp_result))
	result = np.array(result)
	all_result=np.array(all_result)
	all_result_0=np.array(all_result_0)
	all_result=np.apply_along_axis(np.mean,0,all_result)
	all_result_0=np.apply_along_axis(np.mean,0,all_result_0)
	opt_k=all_result.argsort()[0]+1
	opt_k_0=all_result_0.argsort()[0]+1
	print([opt_k,opt_k_0, np.min(all_result),np.min(all_result_0) ])
	np.save("inter_"+str(gamma)+"_"+str(i)+"_"+sys.argv[3]+"_all.npy",np.array([n_train, opt_k,np.min(all_result), opt_k_0,np.min(all_result_0)] ))
	np.save("inter_"+str(gamma)+"_"+str(i)+"_"+sys.argv[3]+".npy",tmp_result)



