import numpy as np
import matplotlib.pyplot as plot

a=np.zeros([3,7,8,2])
c=np.zeros([3,7,8,2])
for j in range(0,3):
	for k in range(0,8):
		for i in range(0,7):
	#	for j in range(0,3):
			try:
				b=np.load('inter_'+str([2,5,10][j]*[0.05,0.1,0.15,0.2,0.25,0.3,0.35][i])+'_'+str(k)+'_'+str([2,5,10][j])+'.npy')
				tmp=np.apply_along_axis(np.mean,0,b[:20,:])
#				print(i)
#				print(b[:,1])
				tmp1=np.apply_along_axis(np.std,0,b[:20,:])
#				print([i,j,k])
#				print(tmp)
				a[j,i,k,0] = tmp[2]#-tmp[3]
				a[j,i,k,1] = tmp[6]#-tmp[3]
				#print(a[j,i,k,:])
				#print([[2,5,10][j],[0.05,0.1,0.15,0.2,0.25,0.3,0.35][i],k,(tmp[2])/(tmp[6]),tmp[2]-tmp[3] ])
				c[j,i,k,0] = tmp1[2]
				c[j,i,k,1] = tmp1[6]
			except:
				pass


color = ['#1aa0dd','#851add','#dd1a78','#dd541a','#ffd230','#07b71e']

x=np.array([0.05,0.1,0.15,0.2,0.25,0.3,0.35])

k=5

for j in [0,1,2]:
	print(j)
	print(a[j,:,4,0])
	print(a[j,:,4,1])
	print(c[j,:,4,0])
	print(c[j,:,4,1])
	plot.plot(x,a[j,:,4,0]/a[j,:,4,1],color=color[j],marker="+",linestyle='-',label='d='+str([2,5,10][j] ))
#	plot.plot(x,a[j,:,k,1],color=color[j],marker="+",linestyle='--',label='d='+str([2,5,10][j] ))
	#plot.plot(x,b[i,0,],color=color[i],linestyle='-',label='d='+str(group[i])+' 1nn')
	#plot.plot(x,b[i,1,],color=color[i],linestyle='--',label='d='+str(group[i])+' knn')


plot.ylabel('Regret Ratio')
plot.xlabel('omega')
plot.legend( )
plot.show()
