# import the necessary packages
from __future__ import print_function
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report
from sklearn import datasets
from sklearn.datasets import fetch_openml
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler
from sklearn.utils import check_random_state
from skimage import exposure
import numpy as np
import imutils
import cv2
import sklearn
from SubNN import SubNN
import sys
import pandas as pd

gamma = [0,0.05,0.1,0.15,0.2,0.25,0.3,0.35]
gamma = gamma[int(sys.argv[2])]

# handle older versions of sklearn
if int((sklearn.__version__).split(".")[1]) < 18:
	from sklearn.cross_validation import train_test_split
 
# otherwise we're using at lease version 0.18
else:
	from sklearn.model_selection import train_test_split


if sys.argv[1] == 'mnist':
	# Load data from https://www.openml.org/d/554
	X, y = fetch_openml('mnist_784', version=1, return_X_y=True)
	y = y.astype('float')
	y[y<5] = 0
	y[y>=5] = 1
	k_max = 50
	num_class = 2


if sys.argv[1] == 'mnist_small':
	mnist = datasets.load_digits()
	X = mnist.data
	y = mnist.target
	y = y.astype('float')
	y[y<5] = 0
	y[y>=5] = 1
	k_max = 30
	num_class = 2

if sys.argv[1] == 'HTRU2':
	data = pd.read_csv('HTRU_2.csv')
	data = data.as_matrix()
	X = data[:,:8].copy()
	y = data[:,8].copy()
	n_train = y.shape[0]
	X_mean = np.apply_along_axis(np.mean,0,X)
	X = X - X_mean.repeat(n_train).reshape([8,n_train]).transpose()
	X2 = np.apply_along_axis( np.sum, 0, np.power(X,2) )
	X = X / np.sqrt(X2).repeat(n_train).reshape([8,n_train]).transpose()*np.sqrt(n_train)
	k_max = 50
	num_class = 2


if sys.argv[1] == 'Credit':
	data = pd.read_csv('Credit.csv',header=1)
	data = data.as_matrix()
	X = data[:,:23].copy()
	y = data[:,23].copy()
	n_train = y.shape[0]
	X_mean = np.apply_along_axis(np.mean,0,X)
	X = X - X_mean.repeat(n_train).reshape([23,n_train]).transpose()
	X2 = np.apply_along_axis( np.sum, 0, np.power(X,2) )
	X = X / np.sqrt(X2).repeat(n_train).reshape([23,n_train]).transpose()*np.sqrt(n_train)
	k_max=100
	num_class = 2

if sys.argv[1] == 'Abalone':
        data = pd.read_csv('abalone.data')
        data = data.as_matrix()
        X = data[:,1:8].copy()
        y = data[:,8].copy()
        y[y<=9] = 0
        y[y>9] = 1
        n_train = y.shape[0]
        X_mean = np.apply_along_axis(np.mean,0,X)
        X = X - X_mean.repeat(n_train).reshape([7,n_train]).transpose()
        X2 = np.apply_along_axis( np.sum, 0, np.power(X,2) )
        X = X / np.sqrt(X2).repeat(n_train).reshape([7,n_train]).transpose()*np.sqrt(n_train)
        k_max = 100
        num_class = 2
        y=y.astype('int')

print(X.shape)

def train(train_x,train_y,test_x,test_y,k_max):
	dim = test_x.shape[1]
	n_train = train_y.size
	n_test = test_y.size
	k_max = int(k_max)
	predict = np.zeros([n_test, k_max])
	for i in range(0,n_test):
		dist = train_x - test_x[i,:].repeat(n_train).reshape([dim, n_train]).transpose()
		dist = dist*dist
		dist = np.apply_along_axis(np.sum, 1, dist).reshape(n_train)
		dist = np.sqrt(dist)
		order = dist.argsort()
		tmp_train_y = train_y[order]
		tmp_dist = dist[order]
		if tmp_dist[0] > 0:
			tmp_dist = np.power(tmp_dist, -gamma*dim)
			result = tmp_train_y*tmp_dist
			result = result.cumsum()
			result = result / tmp_dist.cumsum()
			result = result.reshape(n_train)
			result = result[range(0,k_max)]
		else:
			result = tmp_train_y[0].repeat(k_max).reshape(k_max)
		predict[i,:] = result.copy()
	predict[predict>0.5] = 1
	predict[predict<=0.5] = 0
	predict = predict - test_y.repeat(k_max).reshape([n_test,k_max])
	predict = predict*predict
	predict = np.apply_along_axis(np.sum, 0, predict).reshape(k_max)
	return predict/n_test


def cv(train_x,train_y,test_x,test_y,num_fold,k_max):
	k_max = int(k_max)
	dim = train_x.shape[1]
	n_train = train_y.size
	num_each = int(n_train / num_fold)
	num_fold = int(num_fold)
	k_max = int(k_max)
	predict = np.zeros([num_fold, k_max])
	for i in range(0,num_fold):
		start = num_each*i
		end = num_each*(i+1) - 1
		end = min(end,n_train)
		train_index = range(start,end+1)
		index = range(0,n_train)
		test_index = np.concatenate((index[:start],index[(end+1):]))
		test_index = test_index.astype('int')
		x2 = train_x[train_index,:]
		x1 = train_x[test_index,:]
		y2 = train_y[train_index]
		y1 = train_y[test_index]
		tmp = train(train_x=x1, train_y=y1, test_x=x2, test_y=y2, k_max=k_max)
		#print(tmp)
		predict[i,:] = tmp.copy()
		#print("finish folder ",i)
	#print(predict)
	predict = np.apply_along_axis(np.mean, 0, predict).reshape(k_max)
	#print(predict)
	opt_k = predict.argsort()[0]
	print(opt_k)
	opt_k = int(round(opt_k*(num_fold/(num_fold-1))**(4/(4+dim))))+1
	result =  train(train_x=train_x,train_y=train_y,test_x=test_x,test_y=test_y,k_max=max(k_max,n_train-1))
	result1 = result[opt_k-1]
	result2 = result.argsort()[0]+1
	print(result[result2-1])
	#result = train(train_x=train_x,train_y=train_y,test_x=test_x,test_y=test_y,k_max=opt_k)[opt_k-1]
	return [n_train, opt_k, result1,0, result2]



for i in range(0,50):
	random_state = check_random_state(i)
	print(X.shape)
	permutation = random_state.permutation(X.shape[0])
	X = X[permutation]
	y = y[permutation]
	X = X.reshape((X.shape[0], -1))
	
	if sys.argv[1] == 'mnist':
		X = X[0:3000,]
		y = y[0:3000,]

	if sys.argv[1] == 'mnist':
		(trainData, testData, trainLabels, testLabels) = train_test_split( X, y, test_size=0.3333333, random_state=42)
	else:
		(trainData, testData, trainLabels, testLabels) = train_test_split( X, y, test_size=0.75, random_state=42)

	dim = trainData.shape[1]
	n_test = testLabels.shape[0]

	result = cv(num_fold=5,k_max=k_max,train_x=trainData,train_y=trainLabels,test_x=testData,test_y=testLabels)

	result = np.array(result)

	np.save("inter_real/inter_real_"+str(i)+"_"+sys.argv[1]+"_"+sys.argv[2]+".npy",result)

"""
# show the sizes of each data split
print("training data points: {}".format(len(trainLabels)))
print("testing data points: {}".format(len(testLabels)))

# initialize the values of k for our k-Nearest Neighbor classifier along with the
# list of accuracies for each value of k
kVals = range(1, 30, 2)
accuracies = []
accuracies_1nn = []
 
# loop over various values of `k` for the k-Nearest Neighbor classifier
for k in range(1, 30, 2):
	# train the k-Nearest Neighbor classifier with the current value of `k`
	model = KNeighborsClassifier(n_neighbors=k)
	model.fit(trainData, trainLabels)
 
	# evaluate the model and update the accuracies list
	score = model.score(testData, testLabels)
	accuracies.append(score)
	print("k=%d, accuracy=%.2f%%" % (k, score * 100))
	model = SubNN(k_train=k,n_model=1,subSampleRatio=1)
	model.fit(trainData, trainLabels)
	score1 = model.error_rate(testLabels, model.predict(testData))
	accuracies_1nn.append(score)
"""

 







